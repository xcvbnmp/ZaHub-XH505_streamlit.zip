import os
import json
import datetime
import streamlit as st
import tensorflow as tf
from keras.models import load_model

# -------- واجهة المشروع --------
st.set_page_config(page_title="ZaHub-XH505", layout="wide")
st.title("ZaHub-XH505 - نظام الذكاء الاصطناعي ورفع المشاريع")
st.markdown("""
<style>
.big-font {
    font-size:22px !important;
    font-weight: bold;
}
</style>
""", unsafe_allow_html=True)

# -------- تحميل النموذج --------
@st.cache_resource
def load_ai_model(path):
    try:
        model = load_model(path)
        return model
    except Exception as e:
        st.error(f"فشل تحميل النموذج: {e}")
        return None

st.markdown("<p class='big-font'>1. تحميل نموذج ذكاء صناعي</p>", unsafe_allow_html=True)
model_file = st.file_uploader("ارفع نموذج (.h5)", type=["h5"])
if model_file:
    with open("model.h5", "wb") as f:
        f.write(model_file.read())
    model = load_ai_model("model.h5")
    if model:
        st.success("تم تحميل النموذج بنجاح")

# -------- إعدادات النظام --------
st.markdown("<p class='big-font'>2. إعدادات النظام</p>", unsafe_allow_html=True)
st.sidebar.header("الإعدادات")
language = st.sidebar.selectbox("اللغة", ["العربية", "English"])
auto_upload = st.sidebar.checkbox("رفع تلقائي للمشروع")
project_name = st.sidebar.text_input("اسم المشروع", value="ZaHub-XH505")
notes = st.sidebar.text_area("ملاحظات المشروع")

# -------- خيارات إضافية --------
st.sidebar.subheader("خيارات إضافية")
download_json = st.sidebar.checkbox("تفعيل حفظ روابط JSON")
display_model_summary = st.sidebar.checkbox("عرض ملخص النموذج")

# -------- عرض ملخص النموذج --------
if model_file and display_model_summary:
    st.markdown("<p class='big-font'>3. ملخص النموذج</p>", unsafe_allow_html=True)
    try:
        summary_str = []
        model.summary(print_fn=lambda x: summary_str.append(x))
        st.text('\n'.join(summary_str))
    except:
        st.warning("تعذر عرض ملخص النموذج")

# -------- حفظ البيانات --------
st.markdown("<p class='big-font'>4. حفظ وإدارة المشروع</p>", unsafe_allow_html=True)
if st.button("حفظ المشروع"):
    now = datetime.datetime.now().isoformat()
    project_data = {
        "project_name": project_name,
        "model_url": "model.h5",
        "interface_url": "http://localhost:8501",
        "upload_time": now,
        "notes": notes
    }
    if download_json:
        with open("project_links.json", "w", encoding="utf-8") as f:
            json.dump(project_data, f, indent=4, ensure_ascii=False)
        st.success("تم حفظ بيانات المشروع في project_links.json")
    st.success("تم حفظ المشروع")
    if auto_upload:
        # placeholder for upload code
        st.info("جاري رفع المشروع تلقائيًا...")

# -------- اختبار النموذج --------
if model_file:
    st.markdown("<p class='big-font'>5. اختبار النموذج</p>", unsafe_allow_html=True)
    sample_input = st.text_input("أدخل قيمة اختبار (رقم أو نص)")
    if st.button("تشغيل النموذج"):
        try:
            result = model.predict([[float(sample_input)]])
            st.success(f"النتيجة: {result[0][0]}")
        except Exception as e:
            st.error(f"حدث خطأ: {e}")
