# ZaHub-XH505 Streamlit Deployment

This project is configured for deployment on Streamlit Cloud.

## Files

- `zahub_app.py`: Main Streamlit application.
- `public/index.html`: Static front-end page.
- `requirements.txt`: Python dependencies.
- `.streamlit/secrets.toml`: Credentials for Firebase, Google Sheets, and GitHub repo.
- `firebase_service_account.json`, `google_credentials.json`: Placeholder credentials.

## Deploy on Streamlit Cloud

1. Push this repository to GitHub.
2. Go to https://streamlit.io/cloud and sign in.
3. Click **New app**, select your GitHub repo and branch.
4. Set the main file to `zahub_app.py`.
5. Click **Deploy**.

Your app will be live shortly.

